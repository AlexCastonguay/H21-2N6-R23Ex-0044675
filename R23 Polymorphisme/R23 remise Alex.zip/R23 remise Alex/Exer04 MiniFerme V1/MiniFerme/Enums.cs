﻿public enum enuStyleDeChien { Compagnie, Garde }
